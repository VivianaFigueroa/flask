from flask import Flask, render_template, request, redirect, session
import random

app = Flask(__name__)
app.secret_key = b' _5#y2L"F4Q8z\n\xec]/'

num = 0

def generate_random_num():
    global num
    num = random.randint(1,100)

@app.route('/count')
def count_index():
    if 'counter' in session:
        session['counter'] = session['counter'] + 1
    else:
            session['counter'] = 1


    return render_template('count_index.html', count =counter)

if __name__ == "__main__":
    app.run(debug=True)