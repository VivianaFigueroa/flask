from flask import Flask, render_template, request, redirect, session
import random

app = Flask(__name__)
app.secret_key = b' _5#y2L"F4Q8z\n\xec]/'

num = 0

def generate_random_num():
    global num
    num = random.randint(1,100)

@app.route('/')
def index():
    if 'counter' in session and 'visitas' in session:
        session['visitas'] += 1
        session['counter'] = session['counter'] + 1
    else:
            session['visitas'] = 1
            session['counter'] = 1

    return render_template('index.html')

@app.route('/destroy', methods=['GET', 'POST'])
def destroy_counter():
    session.clear()
    return redirect('/')

@app.route('/contador_por_2', methods =['GET'])
def contador_por_2():
    session['counter'] += 2
    return render_template('index.html')

@app.route('/contador_por', methods =['POST'])
def contador_por_num():
    num = request.form['counter']
    session['counter'] += int (num)
    return render_template('index.html')


if __name__ == "__main__":
    app.run(debug=True)