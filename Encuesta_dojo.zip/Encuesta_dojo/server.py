from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'csdvsf'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/proceso', methods= ['POST'])
def proceso():
    name = request.form['name']
    print(name)
    session ['name']=name
    ubicacion = request.form['ubicacion']
    print(ubicacion)
    session['ubicacion']=ubicacion
    lenguaje = request.form['lenguaje']
    print(lenguaje)
    session['lenguaje']=lenguaje
    comentario= request.form['comentario']
    print(comentario)
    session['comentario']=comentario
    return redirect('/resultados')

@app.route('/resultados')
def resultados():
    return render_template('datos.html')

if __name__ == "__main__":
    app.run(debug=True)