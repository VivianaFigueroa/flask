from flask import Flask, render_template
app = Flask(__name__)

@app.route( '/' )
def index( ):
    return render_template('index.html')

@app.route('/4')
def cuatro():
    return render_template('cuatro_index.html')

@app.route('/<num1>/<num2>')
def num(num1, num2):
    return render_template('num_index.html', num1=int(num1), num2=int(num2))


if __name__=="__main__":
    app.run(debug=True)
